# JGH Retailer Scan Intelligence - Client Delivery Package

## Contents:
1. **Interactive_Dashboard.html**:
   - Double-click to open in any web browser (Chrome, Edge, Safari, Firefox).
   - No installation or internet server required.
   - Includes interactive filters, charts, KPI scorecards, retailer rankings, and CSV export.

2. **Retailer_Scan_Insights_July2026.xlsx**:
   - Comprehensive multi-sheet corporate Excel workbook.
   - Includes:
     * Executive Summary & Business Answers
     * Query1_Mapped_Scans (Mapped Box_count)
     * Query2_Retailer_Summary (Box_count = SUM(CASE WHEN uom='B5' THEN 0.5 ELSE 1 END))
     * State_Performance (Volume vs Intensity)
     * Daily_Scanning_Trends (Velocity run rate)
     * Category_Analysis (Packaging mix)
     * Raw_Data_Dump (100% full raw transaction dump)

3. **Raw_Data_Dump.csv**:
   - Complete raw transaction dataset for instant import into Power BI, Excel, or SQL.

---
Prepared for Executive Leadership & Client Reporting
